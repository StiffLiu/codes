dat = read.table("DefaultData.txt",header =T)

