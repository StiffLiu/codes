data(Tbrate,package="Ecdat")



tb = as.data.frame(Tbrate)
plot(tb)

plot(Tbrate)

